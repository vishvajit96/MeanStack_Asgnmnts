const promise = require("bluebird");
const mysql = require("mysql");

promise.promisifyAll(require("mysql/lib/Connection").prototype);
promise.promisifyAll(require("mysql/lib/Pool").prototype);

let dbdata = require("./dbdata");

let readAllUser = async () => {
    const connection = mysql.createConnection(dbdata.dbdata);
    await connection.connectAsync();

    let sql = "SELECT * FROM user";
    let result = await connection.queryAsync(sql);

    await connection.endAsync();
    console.log(result);
    return result;
}


let readSelectedUser = async () => {
    const connection = mysql.createConnection(dbdata.dbdata);
    await connection.connectAsync();

    let sql = "SELECT * FROM user WHERE ID=? AND EMAIL=? ";
    let results = await connection.queryAsync(sql, [1, "akshay@gmail.com"]);

    await connection.endAsync();
    console.log(results);
    return results;
};


let readUserByPara = async (id, email) => {
    const connection = mysql.createConnection(dbdata.dbdata);
    await connection.connectAsync();

    let sql = "SELECT * FROM user WHERE ID=? AND EMAIL=? ";
    let results = await connection.queryAsync(sql, [id, email]);

    await connection.endAsync();
    console.log(results);
    return results;
};



let readUserByJsonPara = async (user) => {
    const connection = mysql.createConnection(dbdata.dbdata);
    await connection.connectAsync();

    let sql = "SELECT * FROM user WHERE ID=? AND EMAIL=? ";
    let results = await connection.queryAsync(sql, [user.id, user.email]);

    await connection.endAsync();
    console.log(results);
    return results;
};


module.exports = {
    readAllUser,
    readSelectedUser,
    readUserByPara,
    readUserByJsonPara
};