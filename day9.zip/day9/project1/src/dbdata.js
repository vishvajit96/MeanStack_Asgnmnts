const dbdata = {
    host: "localhost",
    user: "root",
    password: "vishva",
    database: "MY_DB"
}

module.exports = { dbdata };    