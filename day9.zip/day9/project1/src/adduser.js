const Promise = require("bluebird");
const mysql = require("mysql");

Promise.promisifyAll(require("mysql/lib/Connection").prototype);
Promise.promisifyAll(require("mysql/lib/Pool").prototype);

const dbconfig = {
    host: "localhost",
    user: "root",
    password: "vishva",
    databases: "MY_DB",
}

let addUser = async (input) => {
    const connection = mysql.createConnection(dbconfig);
    await connection.connectAsync();

    let sql = "INSERT INTO user (USERNAME,PASSWORD,EMAIL,MOBILE) VALUES (?,?,?,?)";
    await connection.queryAsync(sql, [
        input.username,
        input.password,
        input.email,
        input.mobile
    ]);

    await connection.endAsync();

}