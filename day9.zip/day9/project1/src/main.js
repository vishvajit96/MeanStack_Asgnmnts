const read = require("./read");
//read.readAllUser();
read.readSelectedUser();