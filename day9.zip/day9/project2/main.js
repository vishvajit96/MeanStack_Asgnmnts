const express = require("express");
const { json } = require("express");
//creating an instance of object express
const app = express();

app.get("/", (req, res) => {
    try {
        const json = { message: "Success" };
        res.json(json);
    } catch (err) {
        const json = { message: "fail" };
        res.json(json);
    }
})

app.get("/adduser", (req, res) => {
    try {
        const id = req.query.id;
        const username = req.query.username;
        const password = req.query.password;
        const mobile = req.query.mobile;

        const json = { id, username, password, mobile };
        res.json(json);
    } catch (err) {
        const json = { message: "failToAddUser" };
        res.json(json);
    }
})

/*
app.get("/errorpage",(req,res)=>{
    try{
        const json={}
    }
})
*/
app.listen(3000);