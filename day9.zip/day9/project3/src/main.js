const Promise = require("bluebird");  //npm i bluebird
const mysql = require("mysql");       //npm i mysql
const cors = require("cors");   //npm i cors // install CORS .

Promise.promisifyAll(require("mysql/lib/Connection").prototype);
Promise.promisifyAll(require("mysql/lib/Pool").prototype);


const express = require("express");
const app = express();
app.use(express.json());        //used for POST method :converts text into json
app.use(cors());                //Gives access to browser..

const dbread = require("./dbread");
const dbadd = require("./dbadd");
const dbupdate = require("./dbupdate");

//
// Post API :: (For client Side) ::

app.post("/user", async (req, res) => {
    let data = req.body;
    await dbadd.AddNewUser(data);
});


//
// Get API ::

app.get("/alluser", async (req, res) => {
    try {
        const result = await dbread.ReadAllUser();

        res.json(result);
    } catch (err) {
        const json = { message: "Failure" };
        res.json(json);
    }
});


app.get("/adduser", async (req, res) => {
    try {
        const value = req.query;
        await dbadd.AddNewUser(value);

        const json = { message: "SUCCESS!!!" };
        res.json(json);

    } catch (err) {
        const json = { message: "FAILURE" };
        res.json(json);
    }
});


app.get("/update", async (req, res) => {
    try {
        const value = req.query;
        await dbupdate.UpdateName(value);

        const json = { message: "SUCCESS...!" };
        res.json(json);
    } catch (err) {
        const json = { message: "FAILURE....!" };
        res.json(json);
    }
});




app.listen(3000);