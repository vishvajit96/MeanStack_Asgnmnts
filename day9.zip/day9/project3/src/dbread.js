const Promise = require("bluebird");
const mysql = require("mysql");

Promise.promisifyAll(require("mysql/lib/Connection").prototype);
Promise.promisifyAll(require("mysql/lib/Pool").prototype);

const dbconfig = require("./dbconfig");

let ReadAllUser = async () => {
    const conn = mysql.createConnection(dbconfig.dbconfig);
    await conn.connectAsync();

    let sql = "SELECT * FROM user";
    let result = await conn.queryAsync(sql);

    await conn.endAsync();

    return (result);
};

module.exports = { ReadAllUser };