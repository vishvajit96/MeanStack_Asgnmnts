const Promise = require("bluebird");
const mysql = require("mysql");

Promise.promisifyAll(require("mysql/lib/Connection").prototype);
Promise.promisifyAll(require("mysql/lib/Pool").prototype);

const dbconfig = require("./dbconfig");

let AddNewUser = async (value) => {
    let conn = mysql.createConnection(dbconfig.dbconfig);
    await conn.connectAsync();

    let sql = "INSERT INTO user (NAME,EMAIL,MOBILE,PASSWORD) VALUES (?,?,?,?)"
    await conn.queryAsync(sql, [
        value.name,
        value.email,
        value.mobile,
        value.password
    ]);

    await conn.endAsync();
    return;
};

module.exports = { AddNewUser };
