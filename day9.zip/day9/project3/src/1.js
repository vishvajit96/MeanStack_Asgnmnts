/* Client Side Ajax Call */

let AjaxCall = async () => {
    let name = document.querySelector("#onkar").value;
    let url = "http://localhost:3000/user";
    let input = { name };
    await fetch(url, {
        method: "POST",
        body: JSON.stringify(input),
        headers: {
            "Content-Type": "application/json"
        }
    });
}

