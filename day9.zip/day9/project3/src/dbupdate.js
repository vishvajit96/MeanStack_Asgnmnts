const Promise = require("bluebird");
const mysql = require("mysql");

Promise.promisifyAll(require("mysql/lib/Connection").prototype);
Promise.promisifyAll(require("mysql/lib/Pool").prototype);


const dbconfig = require("./dbconfig");

let UpdateName = async (value) => {
    const conn = mysql.createConnection(dbconfig.dbconfig);
    await conn.connectAsync();

    let sql = "UPDATE user SET NAME=? WHERE ID=?";
    await conn.queryAsync(sql, [
        value.name,
        value.id
    ]);

    await conn.endAsync();
    return;
}

module.exports = { UpdateName };