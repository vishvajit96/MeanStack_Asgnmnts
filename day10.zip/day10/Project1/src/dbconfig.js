let dbconfig = {
    host: "localhost",
    user: "root",
    password: "vishva",
    database: "user"
}

module.exports = { dbconfig };