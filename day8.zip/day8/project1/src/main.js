const Promise = require("bluebird");
const mysql = require("mysql");

Promise.promisifyAll(require("mysql/lib/Connection").prototype);
Promise.promisifyAll(require("mysql/lib/Pool").prototype);

const dbconfg = {
    host: "localhost",
    user: "root",
    password: "vishva",
    database: "MY_DB",
};

let readuser = async () => {
    let connection = mysql.createConnection(dbconfg);
    await connection.connectAsync();

    let sql = "SELECT * FROM user";
    let result = await connection.queryAsync(sql);

    await connection.endAsync();

    console.log(result);
    return result;

}

let InsertNewValueInUser = async () => {
    const connection = mysql.createConnection(dbconfg);
    await connection.connectAsync();

    let sql1 = "INSERT INTO user (NAME,EMAIL,MOBILE,PASSWORD) VALUES (?,?,?,?)";
    let value1 = await connection.queryAsync(sql1, [
        "Onkar Patil",
        "onkar@gmail.com",
        "9096335826",
        "121212"
    ]);

    await connection.endAsync();

    //console.log(value1);
    return value1;
}


readuser();
//InsertNewValueInUser();
